/* *****************************************************************************
 *  Name:              Puru Jaiswal
 *  Last modified:     January 7, 2023
 **************************************************************************** */

import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdRandom;

public class RandomWord {
	public static void main(String[] args) {
		String championWord = "";
		double championResult = 0;
		double num = 0;
		while (!StdIn.isEmpty()) {
			String word = StdIn.readString();
			num++;
			if (StdRandom.bernoulli(1 / num)) {
				championWord = word;
			}
			System.out.println(championWord);
		}
	}
}
